








                                         *IMPORTANT*
if you dont have python then download here
https://www.python.org/downloads/
share this game if you liked it!